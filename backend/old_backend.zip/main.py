from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from schemas import TranslateRequest, TranslateResponse
from model_loader import translate

app = FastAPI(title="AI Translator")

# ======================
# API (มาก่อน)
# ======================
@app.post("/api/v1/translate", response_model=TranslateResponse)
def translate_api(req: TranslateRequest):
    result = translate(
        req.text,
        req.source_lang,
        req.target_lang
    )
    return {"translation": result}

# ======================
# Frontend (Static)
# ======================
app.mount(
    "/ui",
    StaticFiles(directory="../frontend", html=True),
    name="frontend"
)
